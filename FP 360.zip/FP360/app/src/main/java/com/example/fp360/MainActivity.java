package com.example.fp360;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private GridView gridView;
    private DBHelper dbHelper;
    private ArrayAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);
        gridView = findViewById(R.id.inventory_grid_view);

        Button addItemButton = findViewById(R.id.add_item_button);
        Button removeItemButton = findViewById(R.id.remove_item_button);

        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
            startActivity(intent);
        });

        removeItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RemoveItemActivity.class);
            startActivity(intent);
        });

        loadInventory();
    }

    private void loadInventory() {
        List<String> items = dbHelper.getAllItems();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        gridView.setAdapter(adapter);
    }
}
