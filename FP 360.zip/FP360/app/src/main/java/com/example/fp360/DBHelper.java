package com.example.fp360;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_USERS = "Users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_PHONE = "phone";
    private static final Object COLUMN_RECEIVE_SMS = "receive_sms" ;


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Users (UserID INTEGER PRIMARY KEY AUTOINCREMENT, Username TEXT UNIQUE NOT NULL, Password TEXT NOT NULL,COLUMN_RECEIVE_SMS NOT NULL, CELL_PHONE TEXT);");
        db.execSQL("CREATE TABLE Inventory (ItemID INTEGER PRIMARY KEY AUTOINCREMENT, ItemName TEXT NOT NULL, Quantity INTEGER NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Users");
        db.execSQL("DROP TABLE IF EXISTS Inventory");
        onCreate(db);
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Users WHERE Username=? AND Password=?", new String[]{username, password});
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    public void addItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("ItemName", name);
        values.put("Quantity", quantity);
        db.insert("Inventory", null, values);
    }

    @SuppressLint("Range")
    public List<String> getAllItems() {
        List<String> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Inventory", null);
        while (cursor.moveToNext()) {
            items.add(cursor.getString(cursor.getColumnIndex("ItemName")));
        }
        cursor.close();
        return items;
    }

    public void updateItem(int itemId, int quantityChange) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Quantity", quantityChange);
        db.update("Inventory", values, "ItemID=?", new String[]{String.valueOf(itemId)});
    }

    public boolean addUser(String username, String password, String phoneNumber, boolean receiveSms) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_PHONE, phoneNumber);
        values.put(COLUMN_RECEIVE_SMS.toString(), receiveSms ? 1 : 0);
        getWritableDatabase().insert(TABLE_USERS, null, values);
        return receiveSms;
    }

    public void open() {
    }
}





