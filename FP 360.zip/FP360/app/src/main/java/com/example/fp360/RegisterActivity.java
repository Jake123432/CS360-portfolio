package com.example.fp360;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText registerUsernameEditText;
    private EditText registerPasswordEditText;
    private EditText registerConfirmPasswordEditText;
    private EditText phoneNumberInput;
    private Button registerButton;
    private CheckBox smsCheckbox;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DBHelper(this);
        registerUsernameEditText = findViewById(R.id.register_username);
        registerPasswordEditText = findViewById(R.id.register_password);
        registerConfirmPasswordEditText = findViewById(R.id.register_confirm_password);
        phoneNumberInput = findViewById(R.id.phone_number);
        registerButton = findViewById(R.id.register_button);
        smsCheckbox = findViewById(R.id.sms_checkbox);

        registerButton.setOnClickListener(v -> register());
    }

    private void register() {
        String username = registerUsernameEditText.getText().toString();
        String password = registerPasswordEditText.getText().toString();
        String confirmPassword = registerConfirmPasswordEditText.getText().toString();
        String phoneNumber = phoneNumberInput.getText().toString();
        boolean receiveSms = smsCheckbox.isChecked();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill out all required fields", Toast.LENGTH_SHORT).show();
            return;
        }


        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        DBHelper dbHelper = new DBHelper(this);
        dbHelper.open();
        dbHelper.addUser(username, password, phoneNumber, receiveSms); // Implement this method
        dbHelper.close();

            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

