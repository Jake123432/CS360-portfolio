package com.example.fp360;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private EditText itemNameEditText;
    private EditText itemQuantityEditText;
    private Button saveButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        dbHelper = new DBHelper(this);
        itemNameEditText = findViewById(R.id.item_name);
        itemQuantityEditText = findViewById(R.id.item_quantity);
        saveButton = findViewById(R.id.save_button);

        saveButton.setOnClickListener(v -> {
            String name = itemNameEditText.getText().toString();
            int quantity = Integer.parseInt(itemQuantityEditText.getText().toString());


            dbHelper.addItem(name, quantity);
            Toast.makeText(AddItemActivity.this, "Item added", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
